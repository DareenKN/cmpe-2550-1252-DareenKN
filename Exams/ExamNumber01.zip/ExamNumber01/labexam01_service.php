<?php
session_start();
require_once "labexam01_lib.php";
// You shall create your service AJAX request processing here.

// Data received should be cleaned, but only for whitespace and HTML injection.
// No SQL injection cleaning required.
$clean = [];
foreach ($_GET as $key => $value) {
    $clean[trim(strip_tags($key))] = trim(strip_tags($value));
}
// Each of the three button events should be processed and responses sent as 
// described in the exam document.  Use functions to handle the operations for 
// each action.
$action = $clean["action"] ?? "";

// Default response
$response = ["message" => ""];
// Follow the service pattern introduced in class for handling the actions for
// your web service.
switch ($action) {

    case "SubmitNew":
        SubmitNew($clean, $response);
        break;
    case "GetSaved":
        GetSaved($response);
        break;
    case "ClearSaved":
        ClearSaved($response);
        break;
    case "SubmitValue":
        SubmitValue($clean, $response);
        break;

    default:
        $response["message"] = "Invalid action.";
        break;
}

echo json_encode($response);
die();



// This function will generate the array by calling the PartB function in
// the labexam01_lib.php file, and process it as requested.  The output will
// be the processed results or an error message.
function SubmitNew($clean, $response)
{
    global $response;
    $value = $clean["value"];
    if (is_null(value: $value))
        $response["message"] = "You have not provided a number as the Seed Number!";
    if (!(is_numeric($value))) {
        $response["message"] = "You have not provided a number as the Seed Number!";
        return;
    }
    if ($value < 1 || $value > 100) {
        $response["message"] = "The Seed Number must be between 1 and 100 inclusive!";
        return;
    }
    $array = PartB($value);

    $response["array"] = $array;
    $response["message"] = $response["array"];
    $_SESSION["array"] = $array;
}


// This function retrieves the number array from the session (if there is one),
// and then processes it the same as if it was newly submitted and saved.  An error
// message is returned if the array does not exist in the session.
function GetSaved($response)
{
    global $response;
    if (is_null($_SESSION["array"]))
        $response["message"] = "There is no saved number array!";
    else
        $response["message"] = $_SESSION["array"];
}


// This function destroys the session variable storing the array if it exists.
// An error message is returned if the array does not exist in the session.
function ClearSaved($response)
{
    global $response;
    if (is_null($_SESSION["array"]))
        $response["message"] = "There is no saved number array to be deleted!";
    else {
        unset($_SESSION["array"]);
        $response["message"] = "The saved number array has been deleted!";
    }
}

function SubmitValue($clean, $response)
{
    global $response;
    $c1 = $clean["c1"] ?? "";
    $c2 = $clean["c2"] ?? "";
    $c3 = $clean["c3"] ?? "";

    // if (
    //     isset($clean['c1'], $clean['c2'], $clean['c3'])
    // ) {
    // }
}








