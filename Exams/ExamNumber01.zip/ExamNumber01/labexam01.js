// Add your code below this line to set up button listeners, AJAX request methods,
// success functions.
$(document).ready(function () {
    $('#submitNew').click(SubmitNew);
    $('#getSaved').click(GetSaved);
    $('#clearSaved').click(ClearSaved);
});




function SubmitNew() {
    let url = "labexam01_service.php";
    AJAX("GET",
        url,
        "JSON",
        {
            action: "SubmitNew",
            value: $("#seedNum").val()
        },
        function (returnData) {
            console.log(returnData);
            $("#outputPartB").text(returnData.message);
        },
        Bad
    )
}

function GetSaved() {
    let url = "labexam01_service.php";
    AJAX("GET",
        url,
        "JSON",
        {
            action: "GetSaved"
        },
        function (returnData) {
            console.log(returnData);
            $("#outputPartB").text(returnData.message);
        },
        Bad
    )
}

function ClearSaved() {
    let url = "labexam01_service.php";
    AJAX("GET",
        url,
        "JSON",
        {
            action: "ClearSaved"
        },
        function (returnData) {
            console.log(returnData);
            $("#outputPartB").text(returnData.message);
        },
        Bad
    )
}

function SubmitValue() {
    data = {};
    data["action"] = "SubmitValue";
    data["c1"] = $(`input[name="c1"]`).val();
    data["c2"] = $(`input[name="c2"]`).val();
    data["c3"] = $(`input[name="c3"]`).val();
    let url = "labexam01_service.php";
    AJAX("GET",
        url,
        "JSON",
        data,
        function (returnData) {
            console.log(returnData);
            $("#outputPartB").text(returnData.message);
        },
        Bad
    )
}

// Generic function as previously given for initiating AJAX requests
function AJAX(method, url, dataType, data, successCallback, errorCallback) {

    var options = {};
    options["method"] = method;
    options["url"] = url;
    options["dataType"] = dataType;
    options["data"] = data;
    options["success"] = successCallback;
    options["error"] = errorCallback;
    $.ajax(options);

};

// Shared error callback function
function Bad(d, s) {
    console.log(d);
    console.log(s);
}

