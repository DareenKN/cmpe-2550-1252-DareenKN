use dkinganjatou1_pubs
go

select *
from authors

select distinct type
from titles

select * from authors
ORDER BY au_lname;